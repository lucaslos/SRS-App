const express = require('express');
const bodyParser = require('body-parser');
const low = require('lowdb');
const fileAsync = require('lowdb/lib/storages/file-async');

// Start database using file-async storage
// For ease of use, read is synchronous
const db = low('db.json', {
  storage: fileAsync,
});

const router = express.Router();

// Automatically parse request body as JSON
router.use(bodyParser.json());

// GET /posts/:id
router.get('/posts/:id', (req, res) => {
  const post = db.get('posts')
    .find({ id: req.params.id })
    .value();

  res.send(post);
});

// POST /posts
router.post('/posts', (req, res) => {
  db.get('posts')
    .push(req.body)
    .last()
    .assign({ id: Date.now() })
    .write()
    .then(post => res.send(post));
});

module.exports = router;
