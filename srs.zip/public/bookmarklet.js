const getWordsTable = () => {
  const en = document.getElementsByClassName('gt-pb-stc');
  const pt = document.getElementsByClassName('gt-pb-ttc');

  let wordsTable = [];

  fetch('https://localhost/4000/card')
  .then((response) => {
    const result = JSON.parse(response);

    const wordsLimit = result[result.length + 1].front;

    for (let i = 0; i < en.length; i++) {
      if (en[i].innerText === wordsLimit) break;
      wordsTable.push([en[i].innerText.toLowerCase(), pt[i].innerText.toLowerCase()]);
    }

    wordsTable = JSON.stringify(wordsTable);

    prompt(`${i} elements to copy`, wordsTable);
  });
};
