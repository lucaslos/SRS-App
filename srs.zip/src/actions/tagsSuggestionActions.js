export const setTagsSuggestion = tagsSuggestion => ({
  type: 'SET_TAGS_SUGGESTION',
  tagsSuggestion,
});
