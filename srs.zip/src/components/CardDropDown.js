import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

// import * as _Actions from 'actions/_Actions';
// import Group from 'component/Group';

const CompName = () => (
  
);

const mapStateToProps = state => ({
  // change: state.change,
});

const mapDispatchToProps = dispatch => ({
  // set: arg => dispatch(_Actions.set(arg)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CompName);
