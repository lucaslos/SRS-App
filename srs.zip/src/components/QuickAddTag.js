import React from 'react';
import { connect } from 'react-redux';

import * as cardsActions from 'actions/cardsActions';

const QuickAddTag = ({ addTag, tagsSuggestion, cardTags, cardId }) => (
  <div className="quick-add-tag">
    {tagsSuggestion.map((tag, i) => (
      !cardTags.includes(tag) && i < 5
      ? <div className="add-tag button small raised rounded" key={i} onClick={() => { addTag(tag, cardId); }}>{tag}</div>
      : null
    ))}
  </div>
);

const mapStateToProps = state => ({
  tagsSuggestion: state.tagsSuggestion,
  cardTags: state.cards.items[state.revision.position].tags,
  cardId: state.cards.items[state.revision.position].id,
});

const mapDispatchToProps = dispatch => ({
  addTag: (tag, cardId) => dispatch(cardsActions.addTag(tag, cardId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(QuickAddTag);
