import React from 'react';
import PropTypes from 'prop-types';
import TextField from 'components/TextField';
import Icon from 'components/Icon';

const CardFacesFields = () => (

);

CardFacesFields.propTypes = {

};

CardFacesFields.defaultProps = {

};

export default CardFacesFields;
